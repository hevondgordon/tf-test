#!/usr/bin/env bash

# run.sh
# @author Meshach Mitchell<meshach@norustech.com>
# set up routing data and start routing server

# source the helpers for globals and functions
. /valhalla/scripts/helpers.sh

env

# copied some things from GIS.OPS valhalla docker image, hope it works

# we need to either run commands that create files with or without sudo (depends if the image was built with a UID/GID other than 0)
run_cmd() {
  if [[ $(id --user) == "59999" ]] && [[ $(id --group) == "59999" ]]; then
    # -E preserves the env vars, but some are still nulled for security reasons
    # use "env" to preserve them
    $cmd_prefix sudo -E env LD_LIBRARY_PATH=$LD_LIBRARY_PATH $1 || exit 1
  else
    $cmd_prefix $1 || exit 1
  fi
}

# get changes
curl -o updates.osc "$DATA_SERVER_URL/export/changes"
if [ $? -eq 0 ]; then
    # view file, TODO: remove. for debugging purposes only
    cat updates.osc

    # apply hacnges
    osmium apply-changes -o jamaica.osm.pbf jamaica.base.osm.pbf updates.osc && \
    rm jamaica.base.osm.pbf
else
    echo "Error getting updates. Using base map"
    mv jamaica.base.osm.pbf jamaica.osm.pbf
fi

# Process map data
jq ".httpd.service.listen=\"tcp://*:$PORT\"" valhalla-config.json > valhalla.json

run_cmd "/valhalla/scripts/configure_valhalla.sh ${CONFIG_FILE} ${CUSTOM_FILES} ${TILE_DIR} ${TILE_TAR}"

if [[ $(id --user) == "59999" ]] && [[ $(id --group) == "59999" ]]; then
    echo "WARNING: User $(whoami) is running with sudo privileges. Try building the image with a host user's UID & GID."
    # set 775/664 permissions on all created files
    sudo find "${CUSTOM_FILES}" -type d -exec chmod 775 {} \;
    sudo find "${CUSTOM_FILES}" -type f -exec chmod 664 {} \;
else
    find "${CUSTOM_FILES}" -type d -exec chmod 775 {} \;
    find "${CUSTOM_FILES}" -type f -exec chmod 664 {} \;
fi

/valhalla/scripts/run.sh tar_tiles

# start routing server
exec valhalla_service valhalla.json
